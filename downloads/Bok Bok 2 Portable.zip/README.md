# Bok Bok - User Guide (v2.0)

## 🎯 Quick Start

1. **Launch the application**
   - Double-click `bokbok.py` or the executable

2. **Start Recording**
   - Click the "▶ Start" button
   - Wait for status to show "🔴 Recording... Speak now"
   - Begin speaking clearly

3. **See Your Words Appear**
   - Your speech will automatically appear in the text area
   - Text appears in real-time as you speak
   - Each phrase is automatically capitalized and punctuated

4. **Use Voice Commands**
   - Say **"new line"** to move to the next line
   - Say **"new paragraph"** to start a new paragraph
   - Say **"comma"**, **"period"**, etc. for punctuation

5. **Edit the Text**
   - Click anywhere in the text area to edit
   - Fix any mistakes or make changes
   - Use Ctrl+Z to undo, Ctrl+Y to redo

6. **Stop Recording**
   - Click "⏹ Stop" when finished
   - Or say "stop recording" (voice command)

7. **Read Aloud**
   - Click "🔊 All" to read the entire text
   - Select text and click "📖 Selected" to read just that part

8. **Save Your Work**
   - Click "💾 DOCX" for Word document
   - Click "📄 TXT" for plain text file
   - Choose location and filename
   - Click "Save"

## 🔧 Features Explained

### Real-Time Transcription
- Text appears as you speak
- Automatic punctuation (can be disabled)
- Automatic capitalization (can be disabled)
- Smart spacing between sentences

### 🎤 Voice Commands (NEW!)
Control formatting with your voice:
- **"new line"** → Moves cursor to next line
- **"new paragraph"** → Creates a double line break
- **"comma"** → ,
- **"period"** → .
- **"question mark"** → ?
- **"exclamation mark"** → !
- **"colon"** → :
- **"semicolon"** → ;
- **"dash"** → -
- **"quote"** / **"open quote"** / **"close quote"** → "
- **"open parenthesis"** / **"close parenthesis"** → ( )
- **"open bracket"** / **"close bracket"** → [ ]

### 🔊 Text-to-Speech
- **Read All**: Reads the entire transcription aloud
- **Read Selection**: Reads only the text you have highlighted
- **Voice Selection**: Choose between Male, Female, or Default voice types

### Live Editing
- Full text editor with undo/redo
- Copy/paste support (Ctrl+C, Ctrl+V)
- Select all (Ctrl+A)
- Cut (Ctrl+X)
- Find & Replace (Ctrl+F) - standard text editor features

### Save Options
- **DOCX**: Creates formatted Word document with title and timestamp
- **TXT**: Creates plain text file with header
- Both options let you choose filename and location
- Option to open file immediately after saving

### Settings
- **Engine**: Choose recognition engine (Google by default)
- **Auto Punctuation**: Automatically adds periods to sentences
- **Auto Capitalize**: Capitalizes first letter of each phrase
- **Voice**: Select preferred TTS voice
- All settings apply in real-time


## 🎤 Recording Tips

### For Best Results

1. **Environment**
   - Choose a quiet room
   - Minimize background noise
   - Close windows to reduce outside sounds

2. **Microphone**
   - Position 6-12 inches from your mouth
   - Speak directly toward the microphone
   - Use an external USB mic for better quality

3. **Speaking**
   - Speak clearly at normal pace
   - Use natural pauses between thoughts
   - Don't rush or speak too slowly
   - Pronounce words clearly

4. **Calibration**
   - App calibrates on each start
   - Stay quiet during "Calibrating" phase
   - This adjusts for room noise

### Common Commands

- Say **"stop recording"** to stop the current session
- Say **"new paragraph"** to start a new paragraph
- Say **"new line"** for a single line break
- Say **"period"**, **"comma"**, **"question mark"** for punctuation


## ✏️ Editing Your Transcription

### Keyboard Shortcuts

| Action | Windows | macOS |
|--||-|
| Undo | Ctrl+Z | Cmd+Z |
| Redo | Ctrl+Y | Cmd+Shift+Z |
| Copy | Ctrl+C | Cmd+C |
| Paste | Ctrl+V | Cmd+V |
| Cut | Ctrl+X | Cmd+X |
| Select All | Ctrl+A | Cmd+A |

### Text Formatting

The text editor supports:
- Line breaks (press Enter)
- Paragraphs (double Enter)
- Tabs (press Tab)
- Standard text selection (click and drag)


## 💾 Saving Your Work

### Save as DOCX (Word Document)

**What You Get:**
- Formatted Word document
- Professional title: "Bok Bok Transcription"
- Timestamp: Creation date and time
- Clean formatting with Calibri 11pt font
- Ready to use in Microsoft Word, Google Docs, LibreOffice

### Save as TXT (Text File)

**What You Get:**
- Plain text file
- Simple header with title and timestamp
- No formatting
- Universal compatibility
- Small file size


## ⚙️ Settings Guide

### Recognition Engine

**Google (Default)**
- Requires internet connection
- High accuracy
- Supports multiple languages
- Free tier available
- Recommended for most users

### Auto Punctuation

**Enabled (Default):**
- Automatically adds periods to sentences
- Adds proper spacing
- Makes text more readable

**Disabled:**
- No automatic punctuation
- You must say punctuation marks
- More control over exact output

### Auto Capitalize

**Enabled (Default):**
- Capitalizes first letter of each phrase
- Follows standard grammar rules

**Disabled:**
- All lowercase output
- You control capitalization


## 📞 Support

For detailed troubleshooting, see:
- **TROUBLESHOOTING.md** - Common problems and solutions
- **SETUP.md** - Installation help
- **README.md** - General information


## 💡 Pro Tips

1. **Review as you go**: Glance at text occasionally to catch errors early

2. **Use voice commands**: Say "stop recording" to stop hands-free, or "new paragraph" to organize text.

3. **Edit during breaks**: While pausing to think, edit previous text

4. **Save frequently**: Use Save as TXT for quick backups during long sessions

5. **Optimize settings**: Disable auto-punctuation if you want more control

6. **Clear text**: Use Clear button to start fresh without closing app

7. **Multiple saves**: Save as both DOCX and TXT for backup

8. **Keyboard shortcuts**: Learn Ctrl+Z (undo) for quick corrections


**Happy transcribing! 🎤📝**

# Install dependencies
pip install SpeechRecognition pyaudio python-docx language-tool-python pyttsx3

# Run the app
python bokbok.py

🎯 Key Improvements in v2.0
- **Lavender UI Theme**: Beautiful, modern dark theme with lavender accents
- **Voice Commands**: Control formatting with "new line", "new paragraph", and punctuation commands
- **Read Selection**: Read aloud only specific parts of your text
- **Voice Selection**: Choose between Male, Female, or Default voice types for text-to-speech
- **About Section**: Version and author information displayed in sidebar
- **Compact Layout**: Optimized button arrangement for better usability on all screen sizes
- **Responsive Design**: Window resizing improvements
- **Live Editing**: Edit text while recording
- **Dual Format Support**: Save as DOCX or TXT
- **Real-time Word Count**: Track document length

